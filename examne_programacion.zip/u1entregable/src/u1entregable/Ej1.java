package u1entregable;

import java.util.Scanner;

public class Ej1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int suma = 0;
        int contador = 0;
        int mayor = 0;
      

        while (suma <= 100) {
            System.out.print("introduce un número natural ");
            int n = sc.nextInt();
           

            if (n % 2 == 0 && n > 0) {
                suma += n;
                contador++;
                

                if (n > mayor) {
                    mayor = n;
                }
            } else {
                System.out.println("debe introducir un número que sea par.");
            }
        }

        double media = (double) suma / contador;

        System.out.println("media = "+ media);
        System.out.println("numero mayor = " + mayor);

    
    }
}
