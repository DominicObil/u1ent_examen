package u1entregable;

import java.util.Scanner;

public class ej2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       

        ; 
        int n = (int) (Math.random() * 25) + 1;

        System.out.println("hola, adivina el número");

        System.out.println("numero de intentos");
        int itotales = sc.nextInt();

        System.out.println("si quieres ayuda pon true, si no quieres pon false");
        boolean pista = sc.nextBoolean();

        boolean verdadero = false;

        for (int intento = 1; intento <= itotales && !verdadero; intento++) {
            System.out.println("introduce n: ");
            int nusuario = sc.nextInt();

            if (pista) {
                if (nusuario < n) {
                    System.out.println("n es mayor.");
                } else if (nusuario > n) {
                    System.out.println("n es menor.");
                }
            }

            if (nusuario == n) {
                verdadero = true;
                System.out.println("correcto, haz acertado");
           
            }
        }

        if (!verdadero) {
            System.out.println("fallaste, el numero era " + n);
        }

      
    }
}
