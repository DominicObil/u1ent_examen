package u1entregable;

import java.util.Scanner;

public class Ej3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

       
        System.out.print("número de hamburguesas Basicas: ");
        int nhamburguesasB = sc.nextInt();
        System.out.print("número de hamburguesas Gourmet: ");
        int nhamburguesasG = sc.nextInt();


      
        System.out.print("ingrese el día de la semana, 1 para lunes, 2 para martes.....: ");
        int dia = sc.nextInt();
       

      
        double Basica = 3.0;
        double Gourmet = 5.0;

       
        switch (dia) {
      
            case 2: 
          
                Gourmet = 9.0;
                
                break;
            case 3:  
                Basica = 2.0;
                break;
            default:
                break;
                
        }

      
        double precioTotal = (nhamburguesasB * Basica) + ((nhamburguesasG ) * Gourmet);

        
        System.out.print("¿Eres miembro del club Fanegas de Burbur?(true/false) ");
        boolean membresia = sc.nextBoolean();
        
        boolean verdadero = false;
        verdadero = true; {
            double descuento = precioTotal * 0.12;
            precioTotal =  precioTotal - descuento;
        }

   
        System.out.println("El precio total del pedido es: " + precioTotal + "€");

    
    }
}
